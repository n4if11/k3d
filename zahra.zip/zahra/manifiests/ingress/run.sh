helm add repo nginx <>

helm upgrade --install -f values.yaml